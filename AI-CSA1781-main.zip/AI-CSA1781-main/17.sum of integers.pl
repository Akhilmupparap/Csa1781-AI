sum(N, Sum) :-
    Sum is (N + 1) * N / 2.
	write(Sum).
	